package com.example.myapplication;

import static com.example.myapplication.Main2Activity.sigmas;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import androidx.cardview.widget.CardView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
    public double valuex,valuey,valuez,valueflu,valuetH,valuelenght,valueu;
    int valuen;

    public String stability;

   CardView buttonn ;
    String[] letter = {"A","B","C","D","E","F"};
    public static AutoCompleteTextView autoCompletes;
    ArrayAdapter<String> adapterLetter;
    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);
        buttonn=findViewById(R.id.btn2);

        autoCompletes = findViewById(R.id.auto_completes);

        adapterLetter = new ArrayAdapter<String>(this,R.layout.list_letters,letter);
        autoCompletes.setAdapter(adapterLetter);

        autoCompletes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Item: "+item,Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onStart() {
        super.onStart();
        EditText editTextNumberDecimalx_ = findViewById(R.id.editTextNumberDecimal11);
        EditText editTextNumberDecimaly_ = findViewById(R.id.editTextNumberDecimal12);
        EditText editTextNumberDecimalu_ = findViewById(R.id.editTextNumberDecimal10);
        EditText editTextNumberDecimalH_ = findViewById(R.id.editTextNumberDecimal9);
        EditText editTextNumberDecimalflux_ = findViewById(R.id.editTextNumberDecimal13);
        EditText editTextNumbern_=findViewById(R.id.editTextNumberDecimal15);
        EditText editTextlenght=findViewById(R.id.editTextNumberDecimal16);
        buttonn.setOnClickListener(view -> {
            valuex=Double.parseDouble(editTextNumberDecimalx_.getText().toString());
            //  System.out.println("x"+result_txt);
            valuey=Double.parseDouble(editTextNumberDecimaly_.getText().toString());
            //  System.out.println("y "+result_txt);
            valueu=Double.parseDouble(editTextNumberDecimalu_.getText().toString());
            //  System.out.println("z "+result_txt);
            valueflu=Double.parseDouble(editTextNumberDecimalflux_.getText().toString());
            //  System.out.println("Q "+result_txt);
            valuetH=Double.parseDouble(editTextNumberDecimalH_.getText().toString());
            //  System.out.println("Hauteur"+result_txt);
            stability=autoCompletes.getText().toString();
            valuen=Integer.parseInt((editTextNumbern_.getText().toString()));
            valuelenght=Double.parseDouble(editTextlenght.getText().toString());
            String sum = String.valueOf(ConcentrationCalculator(valuex, valueu, valuez, valuetH, valueflu, String.valueOf(autoCompletes), valuelenght, valuen));
            Intent intent =new Intent(getApplicationContext(),Main4Activity.class);
            intent.putExtra("Résultat", sum);
            startActivity(intent);
        });
    }
    public static double[] sigmas(double x, String stability){
        double[] sigmas = new double[2];
        double a , b=0.894, c, d, f;
        if (x < 1000) {
            if (autoCompletes.getText().toString().equals("A")) {
                a = 213;
                c = 440.8;
                d = 1.941;
                f = 9.27;
            } else if (autoCompletes.getText().toString().equals("B")) {
                a = 156;
                c = 106.6;
                d = 1.149;
                f = 3.3;
            } else if (autoCompletes.getText().toString().equals("C")) {
                a = 104;
                c = 61;
                d = 0.911;
                f = 0;
            } else if (autoCompletes.getText().toString().equals("D")) {
                a = 68;
                c = 33.2;
                d = 0.725;
                f = -1.7;
            } else if (autoCompletes.getText().toString().equals("E")) {
                a = 50.5;
                c = 22.8;
                d = 0.678;
                f = -1.3;
            } else {
                a = 34;
                c = 14.35;
                d = 0.74;
                f = -0.35;
            }
        } else {
            if (autoCompletes.getText().toString().equals("A")) {
                a = 213;
                c = 459.7;
                d = 2.094;
                f = -9.6;
            } else if (autoCompletes.getText().toString().equals("B")) {
                a = 156; c = 108.2; d = 1.098; f = 2;
            } else if (autoCompletes.getText().toString().equals("C")) {
                a = 104; c = 61; d = 0.911; f = 0;
            } else if (autoCompletes.getText().toString().equals("D")) {
                a = 68; c = 44.5; d = 0.516; f = -13;
            } else if (autoCompletes.getText().toString().equals("E")) {
                a = 50.5;c = 55.4; d = 0.305; f = -34;
            } else
            {
                a = 34; c = 62.6; d = 0.18; f = -48.6;
            }}

        sigmas[0] = a * Math.pow(x, b);
        sigmas[1] = c * Math.pow(x, d) + f;
        return sigmas;
    }
    public static double ConcentrationCalculator(double x, double u, double z, double h, double Q,String stability,double L,int n) {
        // Déterminer les valeurs de a, b, c, d, f en fonction de la stabilité de l'atmosphère
        double[] sigma = sigmas(x, stability);
        double sigma_z= sigma[1];
        double[] concentrations = new double[n];
        // Calculer les valeurs de sigma_y et sigma_z
        // boucle pour calculer les concentrations pour chaque source
        for (int i = 0; i < n; i++) {
            double q=Q*(Math.pow(10,9))/L;

            double numerator = 2 * q / Math.sqrt(2 * Math.PI) * Math.sqrt(u) * sigma_z;
            double denominator = Math.exp(-Math.pow(z - h, 2) / (2 * Math.pow(sigma_z, 2)));

            concentrations[i] = numerator * denominator;
        }
        // somme de toutes les concentrations
        double sum = 0.0;
        for (int i = 0; i < n; i++) {
            sum += concentrations[i];
        }
        return sum;
    }
}
