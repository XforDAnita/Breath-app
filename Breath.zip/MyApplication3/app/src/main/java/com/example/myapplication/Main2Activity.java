package com.example.myapplication;



import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class Main2Activity extends AppCompatActivity {
    private double valuex,valuey,valuez,valueflu,valuetH,valueu;

    private String stability;
    public static double resultat ;
    private Button boutton;
    String[] letters =  {"A","B","C","D","E","F"};
    public static AutoCompleteTextView autoComplete;

    ArrayAdapter<String> adapterLetters;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        autoComplete = findViewById(R.id.auto_complete);

        adapterLetters = new ArrayAdapter<String>(this, R.layout.list_item, letters);
        autoComplete.setAdapter(adapterLetters);

        autoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String text = parent.getItemAtPosition(position).toString();
                Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
            }
        });

    }
    protected void onStart() {
        super.onStart();
        boutton = findViewById(R.id.button1);
        autoComplete=findViewById(R.id.auto_complete);
        EditText editTextNumberDecimalx_ = findViewById(R.id.x);
        EditText editTextNumberDecimaly_ = findViewById(R.id.y);
        EditText editTextNumberDecimalz_ = findViewById(R.id.z);
        EditText editTextNumberDecimalH_ = findViewById(R.id.Hauteur);
        EditText editTextNumberDecimalflux_ = findViewById(R.id.flux);
        EditText editTextNumberDecimalu_ = findViewById(R.id.u);
        boutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valuex=Double.parseDouble(editTextNumberDecimalx_.getText().toString());
                //  System.out.println("x"+result_txt);
                valuey=Double.parseDouble(editTextNumberDecimaly_.getText().toString());
                //  System.out.println("y "+result_txt);
                valuez=Double.parseDouble(editTextNumberDecimalz_.getText().toString());
                //  System.out.println("z "+result_txt);
                valueflu=Double.parseDouble(editTextNumberDecimalflux_.getText().toString());
                //  System.out.println("Q "+result_txt);
                valuetH=Double.parseDouble(editTextNumberDecimalH_.getText().toString());
                //  System.out.println("Hauteur"+result_txt);
                stability=autoComplete.getText().toString();
                valueu=Double.parseDouble((editTextNumberDecimalu_.getText().toString()));
                String resultat = String.valueOf(calculatePollution(valuex, valuey, valuez, valuetH, valueu,valueflu, String.valueOf(autoComplete)));
                Intent intent =new Intent(getApplicationContext(),Main4Activity.class);
                intent.putExtra("Résultat", resultat);
                startActivity(intent);
            }
        });
    }
    public static double[] sigmas(double x, String stability){
        double[] sigmas = new double[2];
        double a , b=0.894, c, d, f;
        if (x < 1000) {
            if (autoComplete.getText().toString().equals("A")) {
                a = 213;
                c = 440.8;
                d = 1.941;
                f = 9.27;
            } else if (autoComplete.getText().toString().equals("B")) {
                a = 156;
                c = 106.6;
                d = 1.149;
                f = 3.3;
            } else if (autoComplete.getText().toString().equals("C")) {
                a = 104;
                c = 61;
                d = 0.911;
                f = 0;
            } else if (autoComplete.getText().toString().equals("D")) {
                a = 68;
                c = 33.2;
                d = 0.725;
                f = -1.7;
            } else if (autoComplete.getText().toString().equals("E")) {
                a = 50.5;
                c = 22.8;
                d = 0.678;
                f = -1.3;
            } else {
                a = 34;
                c = 14.35;
                d = 0.74;
                f = -0.35;
            }
        } else {
            if (autoComplete.getText().toString().equals("A")) {
                a = 213;
                c = 459.7;
                d = 2.094;
                f = -9.6;
            } else if (autoComplete.getText().toString().equals("B")) {
                a = 156; c = 108.2; d = 1.098; f = 2;
            } else if (autoComplete.getText().toString().equals("C")) {
                a = 104; c = 61; d = 0.911; f = 0;
            } else if (autoComplete.getText().toString().equals("D")) {
                a = 68; c = 44.5; d = 0.516; f = -13;
            } else if (autoComplete.getText().toString().equals("E")) {
                a = 50.5;c = 55.4; d = 0.305; f = -34;
            } else
            {
                a = 34; c = 62.6; d = 0.18; f = -48.6;
            }}

        sigmas[0] = a * Math.pow(x, b);
        sigmas[1] = c * Math.pow(x, d) + f;
        return sigmas;
    }
    public static double calculatePollution(double x, double y, double z, double h, double u , double Q, String stability) {


        double[] sigma = sigmas(x, stability);
        double sigma_y = sigma[0];
        double sigma_z= sigma[1];
            double pi = Math.PI;
            double v = -(Math.pow(y, 2) / (2 * Math.pow(sigma_y , 2))) - (Math.pow((z - h), 2) / Math.pow(sigma_z, 2));
            double denominator = 2 * pi * u * sigma_y * sigma_z;
            resultat = Q*(Math.pow(10,9)) / denominator * Math.exp(v);

        return resultat;
    }


}